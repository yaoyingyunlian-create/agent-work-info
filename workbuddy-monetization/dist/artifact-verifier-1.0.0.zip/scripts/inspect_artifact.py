"""Collect read-only structural evidence. The skill performs semantic review."""
import argparse
import csv
import json
from pathlib import Path
import re
import stat
import xml.etree.ElementTree as ET
import zipfile


PRESENTATION = 'http://schemas.openxmlformats.org/presentationml/2006/main'
SPREADSHEET = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
CHART = 'http://schemas.openxmlformats.org/drawingml/2006/chart'
CHART_PATH = re.compile(r'(?:ppt|word|xl)/charts/chart(?!Ex)[^/]*\.xml')


def inspect_chart(archive, name):
    root = ET.fromstring(archive.read(name))
    results = []
    for series in root.iter(f'{{{CHART}}}ser'):
        values = [
            point.text for field in ('val', 'yVal', 'bubbleSize')
            for element in series.findall(f'{{{CHART}}}{field}')
            for point in element.findall(f'.//{{{CHART}}}pt/{{{CHART}}}v')
            if point.text and point.text.strip()
        ]
        references = [
            formula.text for formula in series.iter(f'{{{CHART}}}f')
            if formula.text and formula.text.strip()
        ]
        results.append({'nonblank_cached_value_count': len(values), 'references': references})
    return {'part': name, 'series_count': len(results), 'series': results}


def inspect_office(path, report):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError('Duplicate package part names')
        main = {'.pptx': 'ppt/presentation.xml', '.xlsx': 'xl/workbook.xml',
                '.docx': 'word/document.xml'}[path.suffix.lower()]
        root = ET.fromstring(archive.read(main))
        if main.startswith('ppt/'):
            if root.tag != f'{{{PRESENTATION}}}presentation':
                raise ValueError('Unsupported presentation namespace or root')
            slide_ids = root.findall(f'{{{PRESENTATION}}}sldIdLst/{{{PRESENTATION}}}sldId')
            report['declared_slide_count'] = len(slide_ids)
        if main.startswith('xl/'):
            if root.tag != f'{{{SPREADSHEET}}}workbook':
                raise ValueError('Unsupported workbook namespace or root')
            sheets = root.findall(f'{{{SPREADSHEET}}}sheets/{{{SPREADSHEET}}}sheet')
            report['declared_sheets'] = [
                {'name': sheet.get('name'), 'state': sheet.get('state', 'visible')}
                for sheet in sheets
            ]
        report['classic_chart_parts'] = [
            inspect_chart(archive, name) for name in sorted(names) if CHART_PATH.fullmatch(name)
        ]
        report['extended_chart_parts'] = [
            name for name in sorted(names)
            if re.fullmatch(r'(?:ppt|word|xl)/charts/chartEx[^/]*\.xml', name)
        ]


def inspect(path):
    report = {'path': str(path)}
    try:
        info = path.stat()
        report['exists'] = True
        if not stat.S_ISREG(info.st_mode):
            report['status'] = 'not_regular_file'
            return report
        report['bytes'] = info.st_size
        if not info.st_size:
            report['status'] = 'empty_file'
            return report
        suffix = path.suffix.lower()
        if suffix in ('.pptx', '.docx', '.xlsx'):
            inspect_office(path, report)
        elif suffix in ('.csv', '.tsv'):
            with path.open(encoding='utf-8-sig', newline='') as source:
                rows = csv.reader(source, delimiter='\t' if suffix == '.tsv' else ',', strict=True)
                report['header'] = next(rows, [])
                report['nonblank_data_rows'] = sum(
                    any(cell.strip() for cell in row) for row in rows
                )
        elif suffix in ('.md', '.txt'):
            report['nonblank_lines'] = sum(
                bool(line.strip()) for line in path.read_text(encoding='utf-8-sig').splitlines()
            )
        else:
            report['status'] = 'requires_viewer'
            return report
        report['status'] = 'structure_read'
    except FileNotFoundError as exc:
        report['status'] = 'read_error' if report.get('exists') else 'missing'
        report['detail'] = str(exc)
        report.setdefault('exists', False)
    except (OSError, KeyError, ValueError, csv.Error, ET.ParseError,
            zipfile.BadZipFile, RuntimeError) as exc:
        report.update(status='read_error', detail=str(exc))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('paths', type=Path, nargs='+')
    args = parser.parse_args()
    print(json.dumps([inspect(path) for path in args.paths], ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
