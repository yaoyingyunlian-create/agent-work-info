import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from inspect_artifact import CHART, PRESENTATION, inspect


class InspectTest(unittest.TestCase):
    def setUp(self):
        workspace = tempfile.TemporaryDirectory()
        self.addCleanup(workspace.cleanup)
        self.root = Path(workspace.name)

    def test_cli_reports_missing_empty_corrupt_and_viewer(self):
        names = ['缺失.csv', '空白.txt', '损坏.pptx', '扫描.pdf']
        for name, content in zip(names[1:], [b'', b'invalid', b'%PDF']):
            (self.root / name).write_bytes(content)
        script = Path(__file__).resolve().parents[1] / 'scripts' / 'inspect_artifact.py'
        result = subprocess.check_output(
            [sys.executable, '-X', 'utf8', str(script)] + [str(self.root / n) for n in names],
            encoding='utf-8',
        )
        self.assertEqual([row['status'] for row in json.loads(result)],
                         ['missing', 'empty_file', 'read_error', 'requires_viewer'])

    def test_csv_quoted_fields_and_blank_row(self):
        path = self.root / '汇总.csv'
        path.write_text('"地区,名称",金额\n华南,0\n,\n', encoding='utf-8-sig')
        result = inspect(path)
        self.assertEqual(result['header'], ['地区,名称', '金额'])
        self.assertEqual(result['nonblank_data_rows'], 1)

    def test_slides_and_chart_cache_evidence(self):
        path = self.root / '报告.pptx'
        with ZipFile(path, 'w') as archive:
            archive.writestr('ppt/presentation.xml',
                             f'<presentation xmlns="{PRESENTATION}"><sldIdLst>'
                             '<sldId/><sldId/></sldIdLst></presentation>')
            archive.writestr('ppt/charts/chart1.xml',
                             f'<chartSpace xmlns="{CHART}"><ser><val><numRef>'
                             '<f>Data!B2</f></numRef></val></ser><ser><val><numLit>'
                             '<pt><v>0</v></pt></numLit></val></ser></chartSpace>')
            archive.writestr('ppt/charts/chart2.xml', f'<chartSpace xmlns="{CHART}"/>')
            archive.writestr('ppt/charts/chartEx1.xml', '<chartSpace/>')
        report = inspect(path)
        self.assertEqual(report['declared_slide_count'], 2)
        first, second = report['classic_chart_parts']
        self.assertEqual(first['series'][0], {'nonblank_cached_value_count': 0,
                                              'references': ['Data!B2']})
        self.assertEqual(first['series'][1]['nonblank_cached_value_count'], 1)
        self.assertEqual(second['series_count'], 0)
        self.assertEqual(report['extended_chart_parts'], ['ppt/charts/chartEx1.xml'])


if __name__ == '__main__':
    unittest.main()
