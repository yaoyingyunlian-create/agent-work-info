"""Collect read-only structural evidence. The skill performs semantic review."""
import argparse
import csv
import json
import math
from pathlib import Path
import posixpath
import re
import stat
from urllib.parse import unquote
import xml.etree.ElementTree as ET
import zipfile


PRESENTATION = 'http://schemas.openxmlformats.org/presentationml/2006/main'
SPREADSHEET = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
CHART = 'http://schemas.openxmlformats.org/drawingml/2006/chart'
CHART_EX = 'http://schemas.microsoft.com/office/drawing/2014/chartex'
REL_ID = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
CHART_PATH = re.compile(r'(?:ppt|word|xl)/charts/chart(?!Ex)[^/]*\.xml')
S = f'{{{SPREADSHEET}}}'


def relationships(archive, part):
    folder, name = posixpath.split(part)
    rels = posixpath.join(folder, '_rels', name + '.rels')
    if rels not in archive.namelist():
        return {}
    return {
        element.attrib['Id']: posixpath.normpath(
            posixpath.join('/' + folder, unquote(element.attrib['Target']))
        ).lstrip('/')
        for element in ET.fromstring(archive.read(rels))
        if element.get('TargetMode') != 'External'
    }


def part_links(archive, part, root, tags):
    relations = relationships(archive, part)
    return [
        {'relationship_id': node.get(REL_ID), 'part': relations.get(node.get(REL_ID)),
         'target_present': relations.get(node.get(REL_ID)) in archive.namelist()}
        for node in root.iter() if node.tag in tags
    ]


def chart_links(archive, part, root):
    return part_links(archive, part, root, (f'{{{CHART}}}chart', f'{{{CHART_EX}}}chart'))


def sheet_drawings(archive, part, root):
    drawings = part_links(archive, part, root, (f'{S}drawing',))
    for drawing in drawings:
        if drawing['target_present']:
            drawing_part = drawing['part']
            try:
                drawing_root = ET.fromstring(archive.read(drawing_part))
                drawing['charts'] = chart_links(archive, drawing_part, drawing_root)
            except ET.ParseError as exc:
                drawing.update(status='read_error', detail=str(exc))
    return drawings


def worksheet_header(root, row_number, shared_strings):
    row = root.find(f"{S}sheetData/{S}row[@r='{row_number}']")
    fields = []
    if row is None:
        return fields
    for cell in row.findall(f'{S}c'):
        value = cell.findtext(f'{S}v') or ''
        kind = cell.get('t')
        if kind == 's':
            if not value.isdecimal() or int(value) >= len(shared_strings):
                raise ValueError(f'Invalid shared string at {cell.get("r")}')
            value = shared_strings[int(value)]
        elif kind == 'inlineStr':
            value = spreadsheet_text(cell.find(f'{S}is'))
        formula = cell.find(f'{S}f')
        if value.strip() or formula is not None:
            fields.append({'cell': cell.get('r'), 'value': value,
                           'formula': formula.text if formula is not None else None})
    return fields


def spreadsheet_text(element):
    if element is None:
        return ''
    nodes = element.findall(f'{S}t') + element.findall(f'{S}r/{S}t')
    return ''.join(node.text or '' for node in nodes)


def is_numeric_point(value):
    try:
        return math.isfinite(float(value))
    except ValueError:
        return False


def inspect_chart(archive, name):
    try:
        root = ET.fromstring(archive.read(name))
    except ET.ParseError as exc:
        return {'part': name, 'status': 'read_error', 'detail': str(exc)}
    if root.tag != f'{{{CHART}}}chartSpace':
        return {'part': name, 'status': 'unsupported_chart_namespace'}
    results = []
    for series in root.iter(f'{{{CHART}}}ser'):
        values = [
            point.text for field in ('val', 'yVal')
            for element in series.findall(f'{{{CHART}}}{field}')
            for point in element.findall(f'.//{{{CHART}}}pt/{{{CHART}}}v')
            if point.text and point.text.strip()
        ]
        references = [
            formula.text for formula in series.iter(f'{{{CHART}}}f')
            if formula.text and formula.text.strip()
        ]
        value_references = [
            formula.text for field in ('val', 'yVal')
            for element in series.findall(f'{{{CHART}}}{field}')
            for formula in element.iter(f'{{{CHART}}}f')
            if formula.text and formula.text.strip()
        ]
        numeric_count = sum(is_numeric_point(value) for value in values)
        results.append({'nonblank_cached_value_count': len(values),
                        'numeric_cached_value_count': numeric_count,
                        'invalid_cached_value_count': len(values) - numeric_count,
                        'references': references,
                        'value_references': value_references})
    return {'part': name, 'series_count': len(results), 'series': results}


def inspect_office(path, report, header_row):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError('Duplicate package part names')
        main = {'.pptx': 'ppt/presentation.xml', '.xlsx': 'xl/workbook.xml',
                '.docx': 'word/document.xml'}[path.suffix.lower()]
        root = ET.fromstring(archive.read(main))
        related = relationships(archive, main)
        if main.startswith('ppt/'):
            if root.tag != f'{{{PRESENTATION}}}presentation':
                raise ValueError('Unsupported presentation namespace or root')
            slide_ids = root.findall(f'{{{PRESENTATION}}}sldIdLst/{{{PRESENTATION}}}sldId')
            report['declared_slide_count'] = len(slide_ids)
            report['slides'] = []
            for number, slide_id in enumerate(slide_ids, 1):
                part = related.get(slide_id.get(REL_ID))
                slide = {'number': number, 'part': part, 'target_present': part in names}
                if part in names:
                    slide_root = ET.fromstring(archive.read(part))
                    slide['hidden'] = slide_root.get('show') in ('0', 'false')
                    slide['charts'] = chart_links(archive, part, slide_root)
                report['slides'].append(slide)
        if main.startswith('xl/'):
            if root.tag != f'{{{SPREADSHEET}}}workbook':
                raise ValueError('Unsupported workbook namespace or root')
            sheets = root.findall(f'{{{SPREADSHEET}}}sheets/{{{SPREADSHEET}}}sheet')
            strings_part = 'xl/sharedStrings.xml'
            shared_strings = [
                spreadsheet_text(item) for item in ET.fromstring(archive.read(strings_part))
            ] if strings_part in names else []
            report['declared_sheets'] = []
            for sheet in sheets:
                part = related.get(sheet.get(REL_ID))
                evidence = {'name': sheet.get('name'), 'state': sheet.get('state', 'visible'),
                            'part': part, 'target_present': part in names}
                if part in names:
                    sheet_root = ET.fromstring(archive.read(part))
                    evidence['drawings'] = sheet_drawings(archive, part, sheet_root)
                    if sheet_root.tag == f'{S}worksheet':
                        evidence['header_row'] = header_row
                        evidence['header_fields'] = worksheet_header(
                            sheet_root, header_row, shared_strings
                        )
                report['declared_sheets'].append(evidence)
        if main.startswith('word/'):
            report['document_body_charts'] = chart_links(archive, main, root)
        report['classic_chart_parts'] = [
            inspect_chart(archive, name) for name in sorted(names) if CHART_PATH.fullmatch(name)
        ]
        report['extended_chart_parts'] = [
            name for name in sorted(names)
            if re.fullmatch(r'(?:ppt|word|xl)/charts/chartEx[^/]*\.xml', name)
        ]


def inspect(path, header_row=1):
    report = {'path': str(path)}
    try:
        info = path.stat()
        report['exists'] = True
        if not stat.S_ISREG(info.st_mode):
            report['status'] = 'not_regular_file'
            return report
        report['bytes'] = info.st_size
        if not info.st_size:
            report['status'] = 'empty_file'
            return report
        suffix = path.suffix.lower()
        if suffix in ('.pptx', '.docx', '.xlsx'):
            inspect_office(path, report, header_row)
        elif suffix in ('.csv', '.tsv'):
            with path.open(encoding='utf-8-sig', newline='') as source:
                rows = csv.reader(source, delimiter='\t' if suffix == '.tsv' else ',', strict=True)
                report['header'] = next(rows, [])
                report['nonblank_data_rows'] = 0
                report['column_count_mismatch_rows'] = []
                for number, row in enumerate(rows, 2):
                    if any(cell.strip() for cell in row):
                        report['nonblank_data_rows'] += 1
                        if len(row) != len(report['header']):
                            report['column_count_mismatch_rows'].append(number)
        elif suffix in ('.md', '.txt'):
            report['nonblank_lines'] = sum(
                bool(line.strip()) for line in path.read_text(encoding='utf-8-sig').splitlines()
            )
        else:
            report['status'] = 'requires_viewer'
            return report
        report['status'] = 'structure_read'
    except FileNotFoundError as exc:
        report['status'] = 'read_error' if report.get('exists') else 'missing'
        report['detail'] = str(exc)
        report.setdefault('exists', False)
    except (OSError, KeyError, ValueError, csv.Error, ET.ParseError,
            zipfile.BadZipFile, RuntimeError) as exc:
        report.update(status='read_error', detail=str(exc))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('paths', type=Path, nargs='+')
    parser.add_argument('--header-row', type=int, default=1, help='Excel header row (1-based)')
    args = parser.parse_args()
    if args.header_row < 1:
        parser.error('--header-row must be positive')
    print(json.dumps([inspect(path, args.header_row) for path in args.paths],
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
