# WorkBuddy 接入与故障处理

技能包是含SKILL.md、scripts、references、assets及requirements.txt的标准目录。ZIP内保留单一school-scheduling顶层目录，不含虚拟环境、真实个人资料或运行结果。具体导入入口以用户WorkBuddy版本为准，不能凭Codex的技能安装方式推断WorkBuddy一定支持。

## 本地运行

1. 解压到可读写目录，确认已安装Python 3.12 x64及Python Launcher。
2. 运行 `powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\setup.ps1`。仅该进程使用Bypass，不修改系统执行策略；首次联网安装依赖到本技能目录.venv。
3. 运行 `powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\run.ps1 --version`，再按SKILL.md生成模板并求解。
4. 自定义虚拟环境可给setup.ps1传-EnvironmentPath；此时直接用该环境python.exe运行scripts/cli.py，run.ps1仍使用包内.venv。

相对输入/输出路径以调用时工作目录为准，建议WorkBuddy始终传绝对路径。依赖不安装到全局环境，不改默认Python。依赖安装失败保留日志，检查网络和Python版本后用同一命令重试，不删用户目录。

## 接入验收

在用户明确要求安装时，使用目标WorkBuddy支持的本地技能导入方式，核实可发现、可触发、可运行Python、可读取用户指定输入、可返回可打开的Excel附件，以及超时/取消能否终止子进程。仅目录存在或ZIP生成不代表这一步已通过。

不自动覆盖用户现有技能、修改WorkBuddy数据库、改写技能缓存或发布到市场。若宿主没有脚本执行能力，提供本地运行命令；服务端接入另行设计。

## 状态与退出码

0为命令执行成功，2为输入/配置错误，3为已证明无解，4为限时无可行解，5为独立校验失败，1为运行异常。最终资格读JSON的ready_for_acceptance。临时UNKNOWN可增加预算重试，不能擅自删硬规则；MODEL_INVALID优先修复模型或规则。

任务产物不得随技能包上传。Excel公式需在用户实际Excel/WPS重算并核对独立统计，Python读写和公式结构检查仅为本地静态证据。
